from filter import *
from clean_genomes import *
from colors import *

#note general form is from [file] import [function], '*' imports everything, all functions
#put __init__.py in the package name.
# package/__init__.py

#all a package is is:

    # a directory w/ possibly subdirs
    # python functions within a .py file, one .py can have many functions, a(), b(), c()
    # an __init__.py file to declare it a package
