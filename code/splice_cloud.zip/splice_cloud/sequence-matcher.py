# here to see various sequences in snake order 1 2 3 4 5 | 2 3 4 5 6 | 3 4 5 6 7 and so on...
#then...detect spliced rna or just sequence matches...
#om a ra pa tsa na dhi
# author: ramneek narayan

#input: text file of genome
#output: vector of sequences, matches, dialogue if so or not...

import string
import os
from time import sleep
import re
from re import search
from filter import my_filter
from clean_genomes import clean_genome


file_path = input("enter the suspect genome file location: ") #write the file path before using program. e.g. ~/Docs/genome.txt

#error handling for typos in file path...
while os.path.exists(file_path) == False:
    file_path = input("typo, try again: ")

suspect_genome = open(file_path,"r")

suspect_genome = clean_genome(suspect_genome)
# now we extract all the sequences for a determined length...

splice_length = input("what is the splice length?: ")

while splice_length.isdigit() == False or int(splice_length) > len(suspect_genome):
    splice_length = input("typo, enter only integers: ")

print("generating sequence partitions...")

splice_length = int(splice_length)

nucleotide_count = len(suspect_genome) #number of nucleotides...

# use a iterator to extract all sequences, sliding style...

item = 0

segments_rna = []

if (item + splice_length) == nucleotide_count:
    segments_rna = segments_rna.append(str(suspect_genome)) #this is more robust, can also check rna of vaccines with past viral infections

else:

    while (item + splice_length) <= nucleotide_count:

        #iterate over the segments...

        sequence = suspect_genome[item:(item + splice_length)]

        #store into segments_rna list:

        segments_rna.append(sequence)

        item += 1 #increment next count


# now we check the actual genome...

true_genome = input("file path of the virus you wish to check for spliced code?: ")

while os.path.exists(file_path) == False:
    file_path = input("typo, try again: ")

check_genome = open(true_genome,"r")

check_genome = clean_genome(check_genome) #a string of genome we wish to check, e.g. corona-19

# check elements of spliced_rna against check_genome:
sleep(2)
print("searching...")

match_list = []

for segment_pos in range(0, len(segments_rna)):

    check_res = search(segments_rna[segment_pos], check_genome)

    match_list.append(check_res)


# from match list, extract tuples of positions, removing 'None' and marking spans...


#now get rid of empty elements...

positions = list(filter(None, match_list))

#now get the tuples for character positions...

for item in range(0, len(positions)):

    positions[item] = re.findall(r'\(.+?\)', str(positions[item]))



# check if there are any matches...

if positions != []:

    pattern_matches = len(positions)

    sleep(2)
    print("done! " + str(pattern_matches) + " matches for a " + str(splice_length) + " splice length found at character positions...")

    print(positions)

    print("the first and the last character tuples of the match are:")

    print(positions[0] + positions[(len(positions)-1)])

    print("in the virus you wished to check for spliced code.")

    #ask for filtered results (too many matches on terminal)

    sleep(1)
    print("would you like filtered results for consequtive matches?")
    ask_filter = input("the result would be (a, b), (b + 1, c + 1) -> (a, c + 1): ")

    while ask_filter != 'yes' and ask_filter != 'y' and ask_filter != 'n' and ask_filter != 'no':
        ask_filter = input("yes or no only, please: ")

    if (ask_filter == 'yes' or ask_filter == 'y'):
        sleep(0.5)
        print("filtering...")
        my_filter(positions)

    elif (ask_filter == 'no' or ask_filter == 'n'):
        sleep(0.5)
        print("won't display filtered results...")


    # now output filtered text files to user if they ask...

    # two genomes are suspect_genome and check_genome

    sus_print = input("would you like the genome for the suspect saved?: ")

    while sus_print != 'yes' and sus_print != 'y' and sus_print != 'n' and sus_print != 'no':
        ask_filter = input("yes or no only, please: ")

    sleep(0.3)
    check_print = input("would you also like the genome for the virus saved?: ")

    while check_print != 'yes' and check_print != 'y' and check_print != 'n' and check_print != 'no':
        ask_filter = input("yes or no only, please: ")


    if sus_print == 'yes' or sus_print == 'y':

        sleep(0.5)
        golden_suspect_name = input("what's the file name you want for the cleaned suspect genome?: ")
        #save to .txt extension

        golden_sus_genome = open(golden_suspect_name, "w")

        golden_sus_genome.write(suspect_genome)
        golden_sus_genome.close()
        sleep(1)
        print("saved! check ./" + str(golden_suspect_name) + " to see genome.")
        sleep(0.5)

    else:
        sleep(0.5)
        print("won't save cleaned suspect genome...")
        sleep(0.5)


    if check_print == 'yes' or check_print == 'y':

        sleep(0.5)
        golden_virus_name = input("what's the file name you want for the cleaned virus genome?: ")
        #save to .txt extension.

        golden_virus_genome = open(golden_virus_name, "w")

        golden_virus_genome.write(check_genome)
        golden_virus_genome.close()
        sleep(1)
        print("saved! check ./" + str(golden_virus_name) + " to see genome.")
        sleep(0.5)

    else:

        sleep(0.5)
        print("won't save cleaned viral genome...")
        sleep(0.5)


    if check_print == 'yes' or check_print == 'y' or sus_print == 'yes' or sus_print == 'y':

        print("happy character inspection!")

#case no matches at all
else:
    sleep(2)
    print("there were no matches for " + str(splice_length) + " splice length.")


#let's test the code:
